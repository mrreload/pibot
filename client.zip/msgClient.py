import os
from socket import *

host = "192.168.1.227" # set to IP address of target computer
port = 8001
addr = (host, port)

def sendMsg(message):
	UDPSock = socket(AF_INET, SOCK_DGRAM)
	msgSent = False
	while not msgSent:
		UDPSock.sendto(message, addr)    	
		UDPSock.close()
		msgSent = True
