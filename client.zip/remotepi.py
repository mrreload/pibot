#!/usr/bin/python

import threading, time
mc = __import__('messageclient')
vc = __import__('vidclient')

thread_list = []


t2 = threading.Thread(target=vc.playvid())
thread_list.append(t2)

t1 = threading.Thread(target=mc.control())
thread_list.append(t1)


# Starts threads
for thread in thread_list:
    thread.start()

for thread in thread_list:
    thread.join()

